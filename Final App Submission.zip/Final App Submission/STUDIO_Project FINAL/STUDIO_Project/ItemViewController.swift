//
//  ItemViewController.swift
//  STUDIO_Project
//
//  Created by Israel Quinonez on 4/2/19.
//  Copyright © 2019 Israel Quinonez. All rights reserved.
//

import UIKit



class ItemViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
   
    
    
    var selectedFoodItemsStruct: FoodItems?
    var selectedNutrientValues: [NutrValues]?
    var calories = 0
    var fat = 0
    var carbs = 0
    var protein = 0
    var sugar = 0
    var fiber = 0
    var sodium = 0
    var cholesterol = 0
    var transFat = 0
    var saturatedFat = 0
    var mainMacrosList : [Int]?
    var mainMacroNames = ["Sugar(g)", "Fiber (g)", "Sodium (mg)", "Cholesterol (mg)", "Trans Fat (g)","Saturated Fat (g)"]
    
    var isHighProtein = false
    var isLowCalorie = false
    var isHighCalorie = false
    var isHighFat = false
    var islowFat = false
    var isLowCarb = false
    var isLowSugar = false
    var isHighSugar = false
    var isHighFiber = false
    var isLowSodium = false
    var isHighSodium = false
    var isLowCholesterol = false
    var isHighCholesterol = false
    var isLowTransFat = false
    var isHighTransFat = false
    var islowSaturatedFat = false
    var isHighSaturatedFat = false
    var isNutrientListConditionalCheck = [""]
    var nutrientSybol = [false]
    
    
    //var dicOfNutrients = NSDictionary[100.0,:0.0]

    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var restaurantNameLabel: UILabel!
    
    @IBOutlet weak var caloriesLabel: UILabel!
    @IBOutlet weak var fatLabel: UILabel!
    
    @IBOutlet weak var carbsLabel: UILabel!
    @IBOutlet weak var proteinLabel: UILabel!
    
    @IBOutlet weak var macrosTableView: UITableView!
    
    @IBOutlet weak var sugarProgressBar: UIProgressView!
    
    @IBOutlet weak var fiberProgressBar: UIProgressView!
    
    @IBOutlet weak var sodiumProgressBar: UIProgressView!
    
    @IBOutlet weak var cholesterolProgressBar: UIProgressView!
    
    @IBOutlet weak var transFatProgress: UIProgressView!
    @IBOutlet weak var saturatedFatProgress: UIProgressView!
    
    @IBOutlet weak var sugarLabel: UILabel!
    @IBOutlet weak var fiberLabel: UILabel!
    
    @IBOutlet weak var sodiumLabel: UILabel!
    @IBOutlet weak var cholesterolLabel: UILabel!
    @IBOutlet weak var transFatLabel: UILabel!
    
    @IBOutlet weak var saturatedFatLabel: UILabel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //scrollView.contentSize = CGSize(width: self.view.frame.size.width, height: self.view.frame.height+100)

       
        for i in (selectedFoodItemsStruct?.full_nutrients)!{
            
            if i.attr_id == 208.0{
                
                caloriesLabel.text = String(Int(i.value!))
                calories = Int(i.value!)
            }
            if i.attr_id == 204.0{
               fat = Int(i.value!)
                fatLabel.text = String(Int(i.value!))
            }
            if i.attr_id == 205.0{
                
               carbs = Int(i.value!)
                carbsLabel.text = String(Int(i.value!))
            }
            if i.attr_id == 203.0{
                protein = Int(i.value!)
                proteinLabel.text = String(Int(i.value!))
            }
            if i.attr_id == 269{
                
                sugar = Int(i.value!)
            }
            if i.attr_id == 291{
                
                fiber = Int(i.value!)
            }
            if i.attr_id == 307{
                
                sodium = Int(i.value!)
            }
            if i.attr_id == 601{
                
                cholesterol = Int(i.value!)
            }
            if i.attr_id == 605{
                
                transFat = Int(i.value!)
            }
            if i.attr_id == 606{
                
                saturatedFat = Int(i.value!)
            }
            
        }
        
        if calories <= 400{
            isNutrientListConditionalCheck.append("Low Calorie")
            nutrientSybol.append(true)
        }
        if protein >= 30{
            isNutrientListConditionalCheck.append("High Protein")
            nutrientSybol.append(true)
        }
        
        if fat >= 30{
            isNutrientListConditionalCheck.append("High Fat")
            nutrientSybol.append(false)
        }
        if fat <= 10{
            isNutrientListConditionalCheck.append("Low Fat")
            nutrientSybol.append(true)
        }
        if carbs <= 15{
            isNutrientListConditionalCheck.append("Low Carb")
            nutrientSybol.append(true)
        }
        if sugar <= 10{
            isNutrientListConditionalCheck.append("Low Sugar")
            nutrientSybol.append(true)
            
        }
        if sugar >= 30{
            isNutrientListConditionalCheck.append("High Sugar")
            nutrientSybol.append(false)
        }
     
        
        if fiber >= 5{
            isNutrientListConditionalCheck.append("High Fiber")
            nutrientSybol.append(true)
        }
        if sodium <= 160{
            isNutrientListConditionalCheck.append("Low Sodium")
            nutrientSybol.append(true)
        }
        if sodium >= 400{
            isNutrientListConditionalCheck.append("High Sodium")
            nutrientSybol.append(false)
        }
        
        if cholesterol <= 20{
            isNutrientListConditionalCheck.append("Low Cholesterol")
            nutrientSybol.append(true)
        }
        if cholesterol >= 50{
            isNutrientListConditionalCheck.append("High Cholesterol")
            nutrientSybol.append(false)
        }
        if transFat == 0{
            isNutrientListConditionalCheck.append("Zero Trans Fat")
            nutrientSybol.append(true)
        }
        if transFat >= 3{
            isNutrientListConditionalCheck.append("High Trans Fat")
            nutrientSybol.append(false)
        }
        if saturatedFat <= 4{
            isNutrientListConditionalCheck.append("Low Saturated Fat")
            nutrientSybol.append(true)
        }
        if saturatedFat >= 10{
            isNutrientListConditionalCheck.append("High Saturated Fat")
            nutrientSybol.append(false)
        }
      
       
        mainMacrosList = [sugar,fiber,sodium,cholesterol,transFat,saturatedFat]

        macrosTableView.tableFooterView = UIView()
        macrosTableView.reloadData()
        
        //for i in selectedNutrientValues!{
          //  dicOfNutrients![i.attr_id!] = i.value
            
        //}
        itemName.text = selectedFoodItemsStruct?.food_name
        restaurantNameLabel.text = selectedFoodItemsStruct?.brand_name
        //restaurantNameLabel.text = (selectedFoodItemsStruct?.serving_unit)! + "" + String((selectedFoodItemsStruct?.serving_qty)!)
        
        
       
        
        print("test")
      
       // sugarProgressBar.progress = Float(Double(sugar)/38.0)
        
        
      //  sodiumProgressBar.progress = Float(Double(sodium)/2300.00)
      //  cholesterolProgressBar.progress = Float(Double(cholesterol)/300.0)
     //   fiberProgressBar.progress = Float(Double(fiber)/25.0)
     //   transFatProgress.progress = Float(Double(transFat)/5.0)
      //  saturatedFatProgress.progress = Float(Double(saturatedFat)/13.0)
        sugarProgressBar.progress = Float(Double(sugar)/25.0) // was 12.6

        sodiumProgressBar.progress = Float(Double(sodium)/2400.0)//was 766
        cholesterolProgressBar.progress = Float(Double(cholesterol)/300.0) // was 300
        fiberProgressBar.progress = Float(Double(fiber)/25.0) //was 10
        transFatProgress.progress = Float(Double(transFat)/2.0)
        saturatedFatProgress.progress = Float(Double(saturatedFat)/20.0) // was 4.3
       
        sugarLabel.text = "Sugar"+" ("+String(sugar)+"g)"
        fiberLabel.text = "Fiber"+" ("+String(fiber)+"g)"
        sodiumLabel.text = "Sodium"+" ("+String(sodium)+"g)"
        cholesterolLabel.text = "Cholesterol"+" ("+String(cholesterol)+"g)"
        transFatLabel.text = "Trans Fat"+" ("+String(transFat)+"g)"
        saturatedFatLabel.text = "Sat. Fat"+" ("+String(saturatedFat)+"g)"
        
      
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (isNutrientListConditionalCheck.count-1)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "macrosCell", for: indexPath) as! MainMacrosTableViewCell
        for i in isNutrientListConditionalCheck{
            
           // var stringVariable = isNutrientListConditionalCheck[indexPath.row+1]
            cell.macroNameLabelCell.text = isNutrientListConditionalCheck[indexPath.row+1]
           // cell.maroValueLabelCell.text = String(stringVariable)
            if nutrientSybol[indexPath.row+1] == true{
                 cell.alertIconOutlet.image = UIImage(named: "Image-26")
            }
            else{
                
               cell.alertIconOutlet.image = UIImage(named: "Image-27")
            }
           
            
        }
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}
