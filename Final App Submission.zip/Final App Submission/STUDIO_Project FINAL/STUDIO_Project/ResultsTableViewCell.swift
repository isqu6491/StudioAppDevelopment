//
//  ResultsTableViewCell.swift
//  STUDIO_Project
//
//  Created by Israel Quinonez on 4/25/19.
//  Copyright © 2019 Israel Quinonez. All rights reserved.
//

import UIKit

class ResultsTableViewCell: UITableViewCell {

    @IBOutlet weak var itemNameOutlet: UILabel!
    
    @IBOutlet weak var restaurantNameOutlet: UILabel!
    @IBOutlet weak var detailOutlet: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
